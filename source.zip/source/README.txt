Compile the ��driver�� project directly in Visual Studio.
Require installed: Gurobi 6.0, Google sparsehash

Command to run:
driver.exe<space>mapfile<space>agentfile

Email:
hangma@usc.edu
